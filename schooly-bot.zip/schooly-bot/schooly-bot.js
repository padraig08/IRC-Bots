var config = {
	channels: ["#bots"],
	server: "irc.teamschoolyd.org",
	botName: "Schooly-B"
};

//set above to #tsd or other channels when ready


var irc = require("irc");
var request = require('request');

var ebola = {
	commands: ['ebola','owl'],
	items: ['https://www.youtube.com/watch?v=CPqomrYO960',
			'https://www.youtube.com/watch?v=nKqs1JLDbp4',
			'https://www.youtube.com/watch?v=ts7--zxXXKQ']
			//Add items to be randomly selected to list above
};

function getRandomInt(min,max){
	var rando = Math.floor(Math.random() * (max - min +1)) + min;
	return rando;
}


var bot = new irc.Client(config.server, config.botName, {
	channels: config.channels
});

var commands = {
		ebola: '^.'+ebola.commands[0]+'(.*)$',
		owl: '^.'+ebola.commands[1]+'(.*)$'};
	
	var ebolaPattern = new RegExp(commands.ebola);
	var owlPattern = new RegExp(commands.owl);


bot.addListener("message#bots", function(from, text, message) {


	if(ebolaPattern.test(text)){
		var ebolaLink = getRandomInt(0,ebola.items.length-1);
		bot.say(config.channels[0], ebola.items[ebolaLink]);
	}

});
